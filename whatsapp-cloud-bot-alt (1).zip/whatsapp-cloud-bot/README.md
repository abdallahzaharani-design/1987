# WhatsApp Cloud Bot (Node.js)
مشروع جاهز للنشر لتشغيل شات بوت واتساب باستخدام WhatsApp Cloud API.

## الإعداد على Render
- Build: `npm install`
- Start: `npm start`
- Env: VERIFY_TOKEN, WHATSAPP_TOKEN, PHONE_NUMBER_ID
